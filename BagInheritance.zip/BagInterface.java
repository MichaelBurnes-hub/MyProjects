public interface BagInterface<T>
{
//Current number of entries in bag

public int getCurrentSize();
// Adds a new entry to bag
public boolean add(T newEntry);
// Retrieves all entries in bag
public T[] toArray();
}